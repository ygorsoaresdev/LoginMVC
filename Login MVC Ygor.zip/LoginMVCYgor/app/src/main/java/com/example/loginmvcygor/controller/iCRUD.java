package com.example.loginmvcygor.controller;

import java.util.List;

public interface iCRUD <T> {

    public boolean inserir(T obj);
    public boolean alterar(T obj);
    public boolean deletar(T obj);
    public T buscar(int id);
    public List<T> listar();
}
