package com.example.loginmvcygor.controller;

import android.content.ContentValues;
import android.content.Context;

import com.example.loginmvcygor.datamodel.UsuarioDataModel;
import com.example.loginmvcygor.datasource.AppDataBase;
import com.example.loginmvcygor.model.Usuario;

import java.util.Collections;
import java.util.List;

public class UsuarioController extends AppDataBase implements iCRUD<Usuario> {

    ContentValues dadosDoObjeto;

    public UsuarioController(Context context) {
        super(context);
    }

    @Override
    public boolean inserir(Usuario usuario) {
        dadosDoObjeto = new ContentValues();
        dadosDoObjeto.put("nome", usuario.getNome());
        dadosDoObjeto.put("email", usuario.getEmail());
        dadosDoObjeto.put("senha", usuario.getSenha());

        return insert(UsuarioDataModel.TABELA, dadosDoObjeto);
    }

    @Override
    public boolean alterar(Usuario obj) {
        return false;
    }

    @Override
    public boolean deletar(Usuario obj) {
        return false;
    }

    @Override
    public Usuario buscar(int id) {
        return null;
    }


    @Override
    public List listar() {
        return Collections.emptyList();
    }

    public boolean usuarioeSenha(String username, String password) {
        return checkUserPassword(username, password);
    }

    public boolean usuario(String email) {
        return checkUser( email );
    }
}